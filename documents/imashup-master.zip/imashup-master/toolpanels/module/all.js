dojo.provide('imashup.toolpanels.module.all');

dojo.require('imashup.toolpanels.module.FormElement');