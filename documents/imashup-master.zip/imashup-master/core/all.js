dojo.provide('imashup.core.all');

dojo.require('imashup.core.ComponentTypeManager');
dojo.require('imashup.core.InstanceManager');
dojo.require('imashup.core.ChannelManager');
dojo.require('imashup.core.Channel');