dojo.provide("imashup.tests.module");

try{
    dojo.require("imashup.tests.core.ComponentTypeManager");
    dojo.require("imashup.tests.core.InstanceManager");
    dojo.require("imashup.tests.core.ChannelManager");
	dojo.require("imashup.tests.core.Channel");
	dojo.require("imashup.tests.mixins.Mixins");
    dojo.require("imashup.tests.toolpanels.all");
}catch(e){
    doh.debug(e);
}
