dojo.provide('imashup.tests.toolpanels.all');
if(dojo.isBrowser){
    doh.registerUrl("imashup.tests.toolpanels.Desktop", dojo.moduleUrl("imashup.tests.toolpanels", "Desktop.html"));
    doh.registerUrl("imashup.tests.toolpanels.Docklet", dojo.moduleUrl("imashup.tests.toolpanels", "Docklet.html"));
    doh.registerUrl("imashup.tests.toolpanels.Startbar", dojo.moduleUrl("imashup.tests.toolpanels", "Startbar.html"));
    doh.registerUrl("imashup.tests.toolpanels.PropertiesEditor", dojo.moduleUrl("imashup.tests.toolpanels", "PropertiesEditor.html"));
}