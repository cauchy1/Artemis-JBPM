dojo.provide("imashup.components.all");

dojo.require("imashup.components.gadgets.all");
dojo.require("imashup.components.widgets.all");
