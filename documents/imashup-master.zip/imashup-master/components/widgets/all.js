
dojo.provide("imashup.components.widgets.all");

dojo.require("imashup.components.widgets.InputPane");
dojo.require("imashup.components.widgets.GoogleMap");
dojo.require("imashup.components.widgets.GoogleLineChart");
dojo.require("imashup.components.widgets.WeatherReport");
dojo.require("imashup.components.widgets.Channel");
dojo.require("imashup.components.widgets.DoubanMovies");
dojo.require("imashup.components.widgets.Tudou");
dojo.require("imashup.components.widgets.IPLocation");
dojo.require("imashup.components.widgets.ImageSearch");
dojo.require("imashup.components.widgets.EBay");
dojo.require("imashup.components.widgets.Browser");
